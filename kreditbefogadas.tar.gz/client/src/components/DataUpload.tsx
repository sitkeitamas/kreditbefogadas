import React, { useState } from 'react';
import axios from 'axios';

interface DataUploadProps {
  onUploadSuccess: () => void;
}

const DataUpload: React.FC<DataUploadProps> = ({ onUploadSuccess }) => {
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error' | ''>('');

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      setMessage('Csak Excel fájlok feltöltése engedélyezett (.xlsx, .xls)');
      setMessageType('error');
      return;
    }

    setUploading(true);
    setMessage('');

    const formData = new FormData();
    formData.append('excel', file);

    try {
      const response = await axios.post('/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setMessage(`Sikeres feltöltés! ${response.data.recordsProcessed} rekord feldolgozva.`);
      setMessageType('success');
      onUploadSuccess();
      
      // Clear file input
      event.target.value = '';
    } catch (error: any) {
      setMessage(error.response?.data?.error || 'Hiba történt a feltöltés során');
      setMessageType('error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="data-upload">
      <h2>Excel Fájl Feltöltése</h2>
      <div className="upload-area">
        <input
          type="file"
          accept=".xlsx,.xls"
          onChange={handleFileUpload}
          disabled={uploading}
          id="file-upload"
        />
        <label htmlFor="file-upload" className={`upload-button ${uploading ? 'disabled' : ''}`}>
          {uploading ? 'Feltöltés...' : 'Excel fájl kiválasztása'}
        </label>
      </div>
      
      {message && (
        <div className={`message ${messageType}`}>
          {message}
        </div>
      )}
      
      <div className="upload-info">
        <p><strong>Elvárt oszlopok:</strong></p>
        <ul>
          <li>intézmény</li>
          <li>ország</li>
          <li>teljesített tantárgy</li>
          <li>Corvinusos tantárgy neve</li>
          <li>Corvinusos tantárgy kódja</li>
          <li>tanév</li>
        </ul>
      </div>
    </div>
  );
};

export default DataUpload;
