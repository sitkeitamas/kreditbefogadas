import React from 'react';
import Select from 'react-select';

interface Filters {
  country: string;
  institution: string;
  subject: string;
  academicYear: string;
}

interface FilterOptions {
  countries: string[];
  institutions: string[];
  subjects: string[];
  academic_years: string[];
}

interface DataFilterProps {
  filters: Filters;
  filterOptions: FilterOptions;
  onFilterChange: (filters: Filters) => void;
}

const DataFilter: React.FC<DataFilterProps> = ({
  filters,
  filterOptions,
  onFilterChange,
}) => {
  const handleFilterChange = (field: keyof Filters, value: string) => {
    onFilterChange({
      ...filters,
      [field]: value,
    });
  };

  const clearFilters = () => {
    onFilterChange({
      country: '',
      institution: '',
      subject: '',
      academicYear: '',
    });
  };

  const selectStyles = {
    control: (base: any) => ({
      ...base,
      marginBottom: '1rem',
    }),
  };

  return (
    <div className="data-filter">
      <h2>Szűrők</h2>
      <div className="filter-grid">
        <div className="filter-field">
          <label htmlFor="country-filter">Ország:</label>
          <Select
            id="country-filter"
            value={filterOptions.countries.find(c => c === filters.country) ? 
              { value: filters.country, label: filters.country } : null}
            onChange={(option) => handleFilterChange('country', option?.value || '')}
            options={filterOptions.countries.map(country => ({
              value: country,
              label: country,
            }))}
            isClearable
            placeholder="Válassz országot..."
            styles={selectStyles}
          />
        </div>

        <div className="filter-field">
          <label htmlFor="institution-filter">Intézmény:</label>
          <Select
            id="institution-filter"
            value={filterOptions.institutions.find(i => i === filters.institution) ? 
              { value: filters.institution, label: filters.institution } : null}
            onChange={(option) => handleFilterChange('institution', option?.value || '')}
            options={filterOptions.institutions.map(institution => ({
              value: institution,
              label: institution,
            }))}
            isClearable
            placeholder="Válassz intézményt..."
            styles={selectStyles}
          />
        </div>

        <div className="filter-field">
          <label htmlFor="subject-filter">Teljesített tantárgy:</label>
          <Select
            id="subject-filter"
            value={filterOptions.subjects.find(s => s === filters.subject) ? 
              { value: filters.subject, label: filters.subject } : null}
            onChange={(option) => handleFilterChange('subject', option?.value || '')}
            options={filterOptions.subjects.map(subject => ({
              value: subject,
              label: subject,
            }))}
            isClearable
            placeholder="Válassz tantárgyat..."
            styles={selectStyles}
          />
        </div>

        <div className="filter-field">
          <label htmlFor="academic-year-filter">Tanév:</label>
          <Select
            id="academic-year-filter"
            value={filterOptions.academic_years.find(y => y === filters.academicYear) ? 
              { value: filters.academicYear, label: filters.academicYear } : null}
            onChange={(option) => handleFilterChange('academicYear', option?.value || '')}
            options={filterOptions.academic_years.map(year => ({
              value: year,
              label: year,
            }))}
            isClearable
            placeholder="Válassz tanévet..."
            styles={selectStyles}
          />
        </div>
      </div>

      <button className="clear-filters-button" onClick={clearFilters}>
        Szűrők törlése
      </button>
    </div>
  );
};

export default DataFilter;
