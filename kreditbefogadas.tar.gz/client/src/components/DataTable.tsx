import React from 'react';

interface KreditRecord {
  id?: number;
  institution?: string;
  'intézmény'?: string;
  country?: string;
  'ország'?: string;
  completed_subject?: string;
  'teljesített tantárgy'?: string;
  corvinus_subject_name?: string;
  'Corvinusos  (elfogadtatni kívánt) tantárgy neve'?: string;
  corvinus_subject_code?: string;
  'Corvinusos  (elfogadtatni kívánt) tantárgy kódja'?: string;
  academic_year?: string;
  'tanév'?: string;
}

interface Pagination {
  page: number;
  totalPages: number;
  total: number;
}

interface DataTableProps {
  records: KreditRecord[];
  loading: boolean;
  pagination: Pagination;
  onPageChange: (page: number) => void;
}

const DataTable: React.FC<DataTableProps> = ({
  records,
  loading,
  pagination,
  onPageChange,
}) => {
  if (loading) {
    return (
      <div className="data-table loading">
        <div className="spinner"></div>
        <p>Adatok betöltése...</p>
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="data-table empty">
        <p>Nincs találat a megadott szűrők alapján.</p>
      </div>
    );
  }

  const renderPagination = () => {
    const { page, totalPages } = pagination;
    const maxButtons = 5;
    let startPage = Math.max(1, page - Math.floor(maxButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxButtons - 1);
    
    if (endPage - startPage + 1 < maxButtons) {
      startPage = Math.max(1, endPage - maxButtons + 1);
    }

    const pages = [];
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="pagination">
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="pagination-button"
        >
          « Előző
        </button>
        
        {startPage > 1 && (
          <>
            <button onClick={() => onPageChange(1)} className="pagination-button">1</button>
            {startPage > 2 && <span className="pagination-ellipsis">...</span>}
          </>
        )}
        
        {pages.map(pageNum => (
          <button
            key={pageNum}
            onClick={() => onPageChange(pageNum)}
            className={`pagination-button ${pageNum === page ? 'active' : ''}`}
          >
            {pageNum}
          </button>
        ))}
        
        {endPage < totalPages && (
          <>
            {endPage < totalPages - 1 && <span className="pagination-ellipsis">...</span>}
            <button onClick={() => onPageChange(totalPages)} className="pagination-button">
              {totalPages}
            </button>
          </>
        )}
        
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          className="pagination-button"
        >
          Következő »
        </button>
      </div>
    );
  };

  return (
    <div className="data-table">
      <div className="table-header">
        <h2>Adatok ({pagination.total} találat)</h2>
      </div>
      
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Intézmény</th>
              <th>Ország</th>
              <th>Teljesített tantárgy</th>
              <th>Corvinusos tantárgy neve</th>
              <th>Corvinusos tantárgy kódja</th>
              <th>Tanév</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record, index) => (
              <tr key={record.id || index}>
                <td>{record.institution || record['intézmény']}</td>
                <td>{record.country || record['ország']}</td>
                <td>{record.completed_subject || record['teljesített tantárgy']}</td>
                <td>{record.corvinus_subject_name || record['Corvinusos  (elfogadtatni kívánt) tantárgy neve']}</td>
                <td>{record.corvinus_subject_code || record['Corvinusos  (elfogadtatni kívánt) tantárgy kódja']}</td>
                <td>{record.academic_year || record['tanév']}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {pagination.totalPages > 1 && renderPagination()}
    </div>
  );
};

export default DataTable;
