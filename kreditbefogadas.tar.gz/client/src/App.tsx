import React, { useState, useEffect } from 'react';
import './App.css';
import DataUpload from './components/DataUpload';
import DataFilter from './components/DataFilter';
import DataTable from './components/DataTable';
import axios from 'axios';

interface KreditRecord {
  id?: number;
  institution?: string;
  'intézmény'?: string;
  country?: string;
  'ország'?: string;
  completed_subject?: string;
  'teljesített tantárgy'?: string;
  corvinus_subject_name?: string;
  'Corvinusos  (elfogadtatni kívánt) tantárgy neve'?: string;
  corvinus_subject_code?: string;
  'Corvinusos  (elfogadtatni kívánt) tantárgy kódja'?: string;
  academic_year?: string;
  'tanév'?: string;
}

interface Filters {
  country: string;
  institution: string;
  subject: string;
  academicYear: string;
}

function App() {
  const [records, setRecords] = useState<KreditRecord[]>([]);
  const [filters, setFilters] = useState<Filters>({
    country: '',
    institution: '',
    subject: '',
    academicYear: ''
  });
  const [filterOptions, setFilterOptions] = useState({
    countries: [] as string[],
    institutions: [] as string[],
    subjects: [] as string[],
    academic_years: [] as string[]
  });
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    total: 0
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadFilterOptions();
    loadRecords();
  }, []);

  useEffect(() => {
    loadFilterOptions();
  }, [filters]);

  useEffect(() => {
    loadRecords();
  }, [filters, pagination.page]);

  const loadFilterOptions = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.country) params.append('country', filters.country);
      if (filters.institution) params.append('institution', filters.institution);
      if (filters.subject) params.append('subject', filters.subject);
      if (filters.academicYear) params.append('academicYear', filters.academicYear);

      const response = await axios.get(`/api/filters?${params}`);
      setFilterOptions(response.data);
    } catch (error) {
      console.error('Error loading filter options:', error);
    }
  };

  const loadRecords = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.country) params.append('country', filters.country);
      if (filters.institution) params.append('institution', filters.institution);
      if (filters.subject) params.append('subject', filters.subject);
      if (filters.academicYear) params.append('academicYear', filters.academicYear);
      params.append('page', pagination.page.toString());

      const response = await axios.get(`/api/records?${params}`);
      setRecords(response.data.records);
      setPagination(prev => ({
        ...prev,
        totalPages: response.data.totalPages,
        total: response.data.total
      }));
    } catch (error) {
      console.error('Error loading records:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (newFilters: Filters) => {
    setFilters(newFilters);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  const handlePageChange = (page: number) => {
    setPagination(prev => ({ ...prev, page }));
  };

  const handleDataUploaded = () => {
    loadFilterOptions();
    loadRecords();
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Kreditbefogadás Adatfeldolgozó</h1>
      </header>
      <main className="App-main">
        <DataUpload onUploadSuccess={handleDataUploaded} />
        <DataFilter
          filters={filters}
          filterOptions={filterOptions}
          onFilterChange={handleFilterChange}
        />
        <DataTable
          records={records}
          loading={loading}
          pagination={pagination}
          onPageChange={handlePageChange}
        />
      </main>
    </div>
  );
}

export default App;
